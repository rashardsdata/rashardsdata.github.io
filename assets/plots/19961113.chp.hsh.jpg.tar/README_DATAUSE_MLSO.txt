Thank you for downloading our data!

Please use these guidelines when citing:

Include the DOI of the data you are using:

K-Cor DOI: https://doi.org/10.5065/d69g5jv8  
CoMP 1074 nm data DOI: https://doi.org/10.5065/d6r78c8b
CoMP 1079 nm data DOI: https://doi.org/10.5065/d6mg7mjm
CoMP 1083 nm data DOI: https://doi.org/10.5065/d6gq6vsf
Mk4 DOI: https://doi.org/10.5065/d66972c9
Mk3 DOI: https://doi.org/10.5065/d62n5129
CHIP DOI: https://doi.org/10.5065/d6ww7gf7
PICS DOI: https://doi.org/10.5065/d65719tr
Coronado DOI: https://doi.org/10.5065/d6vt1qwp

MLSO Data Citation (for any data from list above):
"Courtesy of the Mauna Loa Solar Observatory, operated by the High Altitude Observatory,
as part of the National Center for Atmospheric Research (NCAR). NCAR is supported by the
National Science Foundation."

UCAR/NCAR TERMS OF USE
Please see https://www.ucar.edu/terms-of-use
